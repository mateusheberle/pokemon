// Urls
const baseUrl = 'pokeapi.co';

// const urlPokemons = 'api/v2/generation/1/';
const urlPokemons1 = 'api/v2/pokemon-species/';
const urlPokemons2 = 'api/v2/pokemon/';
const urlPokemons3 = 'api/v2/evolution-chain/';
