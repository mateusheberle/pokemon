const String notLoaded = 'not loaded...';

class Pokemon {
  Pokemon({
    required this.id,
    required this.name,
    this.color,
    this.sprites,
    this.types,
    this.height,
    this.weight,
    this.abilities,
    this.status,
    this.evolutionUrl,
    this.evolutions,
  });

  int id;
  String name;
  String? color;
  List<String>? sprites;
  List<String>? types;
  int? height;
  int? weight;
  List<String>? abilities;
  List<int>? status;
  String? evolutionUrl;
  List<Pokemon?>? evolutions;

  // factory Pokemon.fromJson(Map<String, dynamic> json) => Pokemon(
  //       id: json['id'],
  //       name: json['name'],
  //       color: json['color']['name'],
  //       sprites: List<String>.from(json['sprites'].map((x) => x)),
  //       types: List<String>.from(json['types'].map((x) => x)),
  //       height: json['height'],
  //       weight: json['weight'],
  //       abilities: List<String>.from(
  //           json['abilities'].map((x) => x['ability']['name'])),
  //       status: List<int>.from(json['status'].map((x) => x['base_stat'])),
  //       evolutionUrl: json['evolution_chain']['url'],
  //       evolutions: json['evolutions'] != null
  //           ? List<String>.from(json['evolutions'].map((x) => x))
  //           : null,
  //     );

  toJson() {
    return {
      'id': id,
      'name': name,
      'color': color,
      'sprites': sprites,
      'types': types,
      'height': height,
      'weight': weight,
      'abilities': abilities,
      'status': status,
      'evolution': evolutionUrl,
      'evolutions': evolutions,
    };
  }

  Pokemon copyWith({
    int? id,
    String? name,
    String? color,
    List<String>? sprites,
    List<String>? types,
    int? height,
    int? weight,
    List<String>? abilities,
    List<int>? status,
    String? evolutionUrl,
    List<Pokemon?>? evolutions,
  }) =>
      Pokemon(
        id: id ?? this.id,
        name: name ?? this.name,
        color: color ?? this.color,
        sprites: sprites ?? this.sprites,
        types: types ?? this.types,
        height: height ?? this.height,
        weight: weight ?? this.weight,
        abilities: abilities ?? this.abilities,
        status: status ?? this.status,
        evolutionUrl: evolutionUrl ?? this.evolutionUrl,
        evolutions: evolutions ?? this.evolutions,
      );
}
