import 'pokemon.dart';

class Catalog {
  Catalog({
    required this.pokemons,
  });

  final List<Pokemon>? pokemons;
}
