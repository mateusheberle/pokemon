import 'package:flutter/material.dart';

class AppStyle {
  static const Color mainColor = Colors.white;
  static const Color mainBackground = Color(0xFF0B0B0E);
}
